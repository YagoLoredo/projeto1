#include <iostream>
#include <iomanip>

using namespace std;

enum Itens {
    ARROZ,
    FEIJAO,
    FARINHA,
    MACARRAO,
    CARNE,
    NUM_ITENS
};

int main() {
    setlocale(LC_ALL, "Portuguese");
    string nomes[NUM_ITENS] = {
        "Arroz",
        "Feijao",
        "Farinha",
        "Macarrao",
        "Carne"
    };

    double precos[NUM_ITENS] = {20.0, 10.0, 5.0, 8.0, 30.0};

    double quantidades[NUM_ITENS];

    double total = 0.0;

    cout << "Digite a quantidade (em kg) de cada item que deseja comprar:" << endl;
    for(int i = 0; i < NUM_ITENS; i++) {
        cout << nomes[i] << ": ";
        cin >> quantidades[i];
        total += quantidades[i] * precos[i];
    }
    cout << fixed << setprecision(2);
    cout << "O valor total da compra �: R$ " << total << endl;

    return 0;
}
