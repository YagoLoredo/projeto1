#include <iostream>
#include <iomanip>

using namespace std;

enum Avaliacoes {
    PROVA1,
    PROVA2,
    TRABALHO,
    NUM_AVALIACOES
};

struct Bimestre {
    float notas[NUM_AVALIACOES];
};

float inserirNota(string tipoNota, float maxNota) {
    float nota;
    do {
        cout << "Insira a nota de " << tipoNota << " (max " << maxNota << "): ";
        cin >> nota;
        if (nota < 0 || nota > maxNota) {
            cout << "Nota inv�lida! Tente novamente." << endl;
        }
    } while (nota < 0 || nota > maxNota);
    return nota;
}

float calcularSomaBimestre(const Bimestre &bimestre) {
    float soma = 0;
    for (int i = 0; i < NUM_AVALIACOES; i++) {
        soma += bimestre.notas[i];
    }
    return soma;
}

void exibirNotasBimestre(const Bimestre &bimestre) {
    cout << "Prova 1: " << bimestre.notas[PROVA1] << endl;
    cout << "Prova 2: " << bimestre.notas[PROVA2] << endl;
    cout << "Trabalho: " << bimestre.notas[TRABALHO] << endl;
}

float calcularMedia(float soma1, float soma2) {
    return (soma1 + soma2) / 2;
}

int main() {
    setlocale(LC_ALL, "Portuguese");
    Bimestre primeiroBimestre;
    Bimestre segundoBimestre;

    cout << "Insira as notas do 1� bimestre:" << endl;
    primeiroBimestre.notas[PROVA1] = inserirNota("Prova 1", 4.0);
    primeiroBimestre.notas[PROVA2] = inserirNota("Prova 2", 4.0);
    primeiroBimestre.notas[TRABALHO] = inserirNota("Trabalho", 2.0);

    cout << "Insira as notas do 2� bimestre:" << endl;
    segundoBimestre.notas[PROVA1] = inserirNota("Prova 1", 4.0);
    segundoBimestre.notas[PROVA2] = inserirNota("Prova 2", 4.0);
    segundoBimestre.notas[TRABALHO] = inserirNota("Trabalho", 2.0);

    #if defined(_WIN32) || defined(_WIN64)
        system("cls");
    #else
        system("clear");
    #endif

    int escolha;
    float soma1 = calcularSomaBimestre(primeiroBimestre);
    float soma2 = calcularSomaBimestre(segundoBimestre);
    float media = calcularMedia(soma1, soma2);

    while (true) {
        cout << "Menu de op��es:" << endl;
        cout << "1 - Mostrar nota do 1� bimestre" << endl;
        cout << "2 - Mostrar nota do 2� bimestre" << endl;
        cout << "3 - Mostrar a m�dia do aluno" << endl;
        cout << "4 - Sair" << endl;
        cin >> escolha;

        switch (escolha) {
            case 1:
                cout << "Notas do 1� bimestre:" << endl;
                exibirNotasBimestre(primeiroBimestre);
                break;
            case 2:
                cout << "Notas do 2� bimestre:" << endl;
                exibirNotasBimestre(segundoBimestre);
                break;
            case 3:
                cout << fixed << setprecision(2);
                cout << "M�dia do aluno: " << media << endl;
                if (media >= 6) {
                    cout << "Aluno aprovado!" << endl;
                } else {
                    cout << "Aluno reprovado!" << endl;
                }
                break;
            case 4:
                cout << "Saindo..." << endl;
                return 0;
            default:
                cout << "Op��o inv�lida! Tente novamente." << endl;
                break;
        }
    }

    return 0;
}
