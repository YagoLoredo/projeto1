#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

enum Esportes {
    FUTEBOL,
    VOLEI,
    BASQUETE,
    NUM_ESPORTES
};

string formatarHorario(int horas, int minutos) {
    ostringstream oss;
    oss << setw(2) << setfill('0') << horas << ":"
        << setw(2) << setfill('0') << minutos;
    return oss.str();
}

int main() {
    setlocale(LC_ALL, "Portuguese");
    string nomes[NUM_ESPORTES] = {
        "Futebol",
        "Volei",
        "Basquete"
    };

    int duracoes[NUM_ESPORTES] = {3, 2, 1};

    vector<int> ordem(NUM_ESPORTES);

    cout << "Digite a ordem dos esportes (0 - Futebol, 1 - Volei, 2 - Basquete):" << endl;
    for(int i = 0; i < NUM_ESPORTES; i++) {
        cin >> ordem[i];
    }
    int horaInicio, minutoInicio;
    cout << "Digite o hor�rio de in�cio da transmiss�o (hora e minuto): ";
    cin >> horaInicio >> minutoInicio;

    cout << "Programa��o completa da transmiss�o:" << endl;
    int horaAtual = horaInicio;
    int minutoAtual = minutoInicio;
    for(int i = 0; i < NUM_ESPORTES; i++) {
        int esporte = ordem[i];
        cout << "Hora " << formatarHorario(horaAtual, minutoAtual) << ", Esporte: " << nomes[esporte] << endl;
        horaAtual += duracoes[esporte];
        if (horaAtual >= 24) {
            horaAtual -= 24;
        }
    }

    return 0;
}
