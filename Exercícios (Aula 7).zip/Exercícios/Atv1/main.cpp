#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;


enum Artilheiros {
    PEDRO_PE_DE_CHUMBO,
    JOAQUIM_FAISCA,
    LEONARDO_BARATA_TONTA,
    ANTONIO_RABO_DE_JACARE,
    NUM_ARTILHEIROS
};

int main() {
    setlocale(LC_ALL, "Portuguese");

    string nomes[NUM_ARTILHEIROS] = {
        "Pedro p� de chumbo",
        "Joaquim fa�sca",
        "Leonardo barata tonta",
        "Ant�nio rabo de jacar�"
    };

    int gols[NUM_ARTILHEIROS] = {30, 22, 15, 11};

    cout << "Artilheiros do Campeonato Brasileiro de Futebol da S�rie E:" << endl;
    for(int i = 0; i < NUM_ARTILHEIROS; i++) {
        cout << nomes[i] << " fez " << gols[i] << " gols." << endl;
    }

    return 0;
}
