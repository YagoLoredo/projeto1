#include <iostream>
#include <string>

using namespace std;

enum Armas {
    REVOLVER,
    ESCOPETA,
    RIFLE,
    NUM_ARMAS
};

string nomes[NUM_ARMAS] = {
    "Revolver",
    "Escopeta",
    "Rifle"
};

int capacidade[NUM_ARMAS] = {6, 8, 10};

int municao[NUM_ARMAS];

int main() {
    setlocale(LC_ALL, "Portuguese");
    for(int i = 0; i < NUM_ARMAS; i++) {
        municao[i] = capacidade[i];
    }

    int armaAtual = REVOLVER;

    int escolha;


    while (true) {
        cout << "Voc� est� usando " << nomes[armaAtual] << " com " << municao[armaAtual] << " balas restantes." << endl;
        cout << "Escolha uma op��o:" << endl;
        cout << "1 - Atirar" << endl;
        cout << "2 - Trocar de arma" << endl;
        cout << "3 - Recarregar" << endl;
        cout << "4 - Sair do jogo" << endl;
        cin >> escolha;

        switch (escolha) {
            case 1:
                if (municao[armaAtual] > 0) {
                    municao[armaAtual]--;
                    cout << "Voc� atirou! Balas restantes: " << municao[armaAtual] << endl;
                } else {
                    cout << "Muni��o esgotada! Recarregue ou troque de arma." << endl;
                }
                break;

            case 2:
                cout << "Escolha uma arma:" << endl;
                for(int i = 0; i < NUM_ARMAS; i++) {
                    cout << i << " - " << nomes[i] << endl;
                }
                cin >> armaAtual;
                if (armaAtual < 0 || armaAtual >= NUM_ARMAS) {
                    cout << "Escolha inv�lida! Mantendo arma atual." << endl;
                    armaAtual = REVOLVER;
                }
                break;

            case 3:
                municao[armaAtual] = capacidade[armaAtual];
                cout << "Voc� recarregou o " << nomes[armaAtual] << ". Muni��o completa!" << endl;
                break;

            case 4:
                cout << "Saindo do jogo." << endl;
                return 0;

            default:
                cout << "Op��o inv�lida! Tente novamente." << endl;
                break;
        }
    }

    return 0;
}
