#include <iostream>
#include <iomanip>

using namespace std;

enum Avioes {
    TUCANO,
    F14,
    F18,
    SR71,
    SR72,
    NUM_AVIOES
};

int main() {
    setlocale(LC_ALL, "Portuguese");
    string nomes[NUM_AVIOES] = {
        "Tucano",
        "F14",
        "F18",
        "SR71",
        "SR72"
    };

    double velocidades[NUM_AVIOES] = {458, 2485, 1915, 3540, 4630};

    const double MACH_CONVERSION = 1225.0;

    double velocidadeNivelMar, velocidade12000Metros;

    int escolha;
    cout << "Selecione o avi�o pelo n�mero correspondente:" << endl;
    for(int i = 0; i < NUM_AVIOES; i++) {
        cout << i << " - " << nomes[i] << endl;
    }
    cin >> escolha;

    if(escolha < 0 || escolha >= NUM_AVIOES) {
        cout << "Escolha inv�lida!" << endl;
        return 1;
    }

    velocidadeNivelMar = velocidades[escolha] * 0.05;
    velocidade12000Metros = velocidades[escolha] * 1.20;

    double machNivelMar = velocidadeNivelMar / MACH_CONVERSION;
    double mach12000Metros = velocidade12000Metros / MACH_CONVERSION;

    cout << fixed << setprecision(2);
    cout << "A velocidade do " << nomes[escolha] << " a n�vel do mar �: "
         << velocidadeNivelMar << " km/h (" << machNivelMar << " Mach)" << endl;
    cout << "A velocidade do " << nomes[escolha] << " a 12000 metros de altitude �: "
         << velocidade12000Metros << " km/h (" << mach12000Metros << " Mach)" << endl;

    return 0;
}
